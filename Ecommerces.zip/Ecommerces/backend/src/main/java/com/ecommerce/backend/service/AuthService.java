package com.ecommerce.backend.service;

import com.ecommerce.backend.entity.User;
import com.ecommerce.backend.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder encoder;

    public AuthService(UserRepository userRepository, BCryptPasswordEncoder encoder) {
        this.userRepository = userRepository;
        this.encoder = encoder;
    }

    // ✅ REGISTER USER
    public User register(User user) {
        user.setPassword(encoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    // ✅ LOGIN USER (WITH DEBUG PRINTS)
    public User login(String email, String password) {

        System.out.println("====== LOGIN DEBUG START ======");

        System.out.println("INPUT EMAIL: " + email);
        System.out.println("INPUT PASSWORD: " + password);

        User user = userRepository.findByEmail(email).orElse(null);

        if (user == null) {
            System.out.println("❌ USER NOT FOUND IN DATABASE");
            System.out.println("====== LOGIN DEBUG END ======");
            return null;
        }

        System.out.println("DB EMAIL: " + user.getEmail());
        System.out.println("DB PASSWORD: " + user.getPassword());

        boolean isMatch = encoder.matches(password, user.getPassword());

        System.out.println("PASSWORD MATCH RESULT: " + isMatch);

        if (isMatch) {
            System.out.println("✅ LOGIN SUCCESS");
            System.out.println("====== LOGIN DEBUG END ======");
            return user;
        } else {
            System.out.println("❌ PASSWORD NOT MATCH");
            System.out.println("====== LOGIN DEBUG END ======");
        }

        return null;
    }
}