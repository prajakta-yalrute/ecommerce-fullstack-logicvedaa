package com.ecommerce.backend.controller;

import com.ecommerce.backend.entity.User;
import com.ecommerce.backend.security.JwtUtil;
import com.ecommerce.backend.service.AuthService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;
    private final JwtUtil jwtUtil;

    public AuthController(AuthService authService, JwtUtil jwtUtil) {
        this.authService = authService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        if (user.getRole() == null || user.getRole().isBlank()) {
            user.setRole("CUSTOMER");
        }
        return authService.register(user);
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> userRequest) {

        String email = userRequest.get("email");
        String password = userRequest.get("password");

        User user = authService.login(email, password);

        if (user != null) {
            String token = jwtUtil.generateToken(user.getEmail(), user.getRole());

            return Map.of(
                    "message", "Login Successful",
                    "role", user.getRole(),
                    "token", token
            );
        }

        return Map.of("message", "Invalid Credentials");
    }
}