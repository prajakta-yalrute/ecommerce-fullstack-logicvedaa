package com.ecommerce.backend.service;

import com.ecommerce.backend.entity.CartItem;
import com.ecommerce.backend.repository.CartRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    private final CartRepository cartRepository;

    public CartService(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    // Add to cart
    public CartItem addToCart(Long userId, Long productId, int quantity) {

        CartItem item = cartRepository
                .findByUserIdAndProductId(userId, productId)
                .orElse(null);

        if (item != null) {
            item.setQuantity(item.getQuantity() + quantity);
        } else {
            item = new CartItem();
            item.setUserId(userId);
            item.setProductId(productId);
            item.setQuantity(quantity);
        }

        return cartRepository.save(item);
    }

    // Get cart
    public List<CartItem> getCart(Long userId) {
        return cartRepository.findByUserId(userId);
    }

    // Update quantity
    public CartItem updateQuantity(Long itemId, int quantity) {
        CartItem item = cartRepository.findById(itemId).orElseThrow();
        item.setQuantity(quantity);
        return cartRepository.save(item);
    }

    // Remove item
    public void removeItem(Long itemId) {
        cartRepository.deleteById(itemId);
    }
}