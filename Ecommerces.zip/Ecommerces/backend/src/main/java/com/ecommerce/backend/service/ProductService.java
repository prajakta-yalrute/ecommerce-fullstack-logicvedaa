package com.ecommerce.backend.service;

import com.ecommerce.backend.entity.Product;
import com.ecommerce.backend.entity.Vendor;
import com.ecommerce.backend.repository.ProductRepository;
import com.ecommerce.backend.repository.VendorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final VendorRepository vendorRepository;

    public ProductService(ProductRepository productRepository, VendorRepository vendorRepository) {
        this.productRepository = productRepository;
        this.vendorRepository = vendorRepository;
    }

    // Vendor creates product
    public Product createProduct(Product product) {
    Vendor vendor = vendorRepository.findById(product.getVendorId())
            .orElseThrow(() -> new RuntimeException("Vendor not found: " + product.getVendorId()));

    if (!"APPROVED".equals(vendor.getKycStatus())) {
        throw new RuntimeException("Vendor is not approved");
    }

    product.setStatus("PENDING");
    return productRepository.save(product);
}

    // Public listing: only approved products
    public List<Product> getApprovedProducts() {
        return productRepository.findByStatus("APPROVED");
    }

    // Vendor sees own products
    public List<Product> getVendorProducts(Long vendorId) {
        return productRepository.findByVendorId(vendorId);
    }

    // Admin sees all pending products
    public List<Product> getPendingProducts() {
        return productRepository.findByStatus("PENDING");
    }

    // Admin approves product
    public Product approveProduct(Long productId) {
        Product product = productRepository.findById(productId).orElseThrow();
        product.setStatus("APPROVED");
        return productRepository.save(product);
    }

    // Admin rejects product
    public Product rejectProduct(Long productId) {
        Product product = productRepository.findById(productId).orElseThrow();
        product.setStatus("REJECTED");
        return productRepository.save(product);
    }
}