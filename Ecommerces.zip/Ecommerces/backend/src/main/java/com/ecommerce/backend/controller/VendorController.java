package com.ecommerce.backend.controller;

import com.ecommerce.backend.entity.Vendor;
import com.ecommerce.backend.service.VendorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/vendors")
public class VendorController {

    private final VendorService vendorService;

    public VendorController(VendorService vendorService) {
        this.vendorService = vendorService;
    }

    // 1. Apply as vendor
    @PostMapping("/apply")
    public Vendor applyVendor(@RequestBody Map<String, String> request) {
        Long userId = Long.parseLong(request.get("userId"));
        String businessName = request.get("businessName");

        return vendorService.applyVendor(userId, businessName);
    }

    // 2. Get pending vendor applications
    @GetMapping("/pending")
    public List<Vendor> getPendingVendors() {
        return vendorService.getPendingVendors();
    }

    // 3. Approve vendor
    @PutMapping("/{vendorId}/approve")
    public Vendor approveVendor(@PathVariable Long vendorId) {
        return vendorService.approveVendor(vendorId);
    }

    // 4. Reject vendor
    @PutMapping("/{vendorId}/reject")
    public Vendor rejectVendor(@PathVariable Long vendorId, @RequestBody Map<String, String> request) {
        String note = request.get("note");
        return vendorService.rejectVendor(vendorId, note);
    }

    // 5. Get vendor by user id
    @GetMapping("/user/{userId}")
    public Vendor getVendorByUserId(@PathVariable Long userId) {
        return vendorService.getVendorByUserId(userId);
    }
}