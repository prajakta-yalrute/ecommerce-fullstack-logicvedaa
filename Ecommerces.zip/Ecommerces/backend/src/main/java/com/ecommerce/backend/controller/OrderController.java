package com.ecommerce.backend.controller;

import com.ecommerce.backend.entity.OrderEntity;
import com.ecommerce.backend.service.OrderService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // Checkout
    @PostMapping("/checkout")
    public OrderEntity checkout(@RequestBody Map<String, String> request) {
        Long userId = Long.parseLong(request.get("userId"));
        return orderService.checkout(userId);
    }

    // Payment simulation
    @PutMapping("/{orderId}/pay")
    public OrderEntity payOrder(@PathVariable Long orderId) {
        return orderService.payOrder(orderId);
    }

    // Update order status
    @PutMapping("/{orderId}/status")
    public OrderEntity updateStatus(@PathVariable Long orderId,
                                    @RequestBody Map<String, String> request) {
        String status = request.get("status");
        return orderService.updateStatus(orderId, status);
    }

    // Get user orders
    @GetMapping("/user/{userId}")
    public List<OrderEntity> getUserOrders(@PathVariable Long userId) {
        return orderService.getUserOrders(userId);
    }

    // Get one order
    @GetMapping("/{orderId}")
    public OrderEntity getOrderById(@PathVariable Long orderId) {
        return orderService.getOrderById(orderId);
    }
}