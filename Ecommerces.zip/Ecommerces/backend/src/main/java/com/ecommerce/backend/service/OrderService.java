package com.ecommerce.backend.service;

import com.ecommerce.backend.dto.OrderStatusMessage;
import com.ecommerce.backend.entity.CartItem;
import com.ecommerce.backend.entity.OrderEntity;
import com.ecommerce.backend.entity.Product;
import com.ecommerce.backend.repository.CartRepository;
import com.ecommerce.backend.repository.OrderRepository;
import com.ecommerce.backend.repository.ProductRepository;
import jakarta.transaction.Transactional;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final CartRepository cartRepository;
    private final ProductRepository productRepository;
    private final SimpMessagingTemplate messagingTemplate;

    public OrderService(OrderRepository orderRepository,
                        CartRepository cartRepository,
                        ProductRepository productRepository,
                        SimpMessagingTemplate messagingTemplate) {
        this.orderRepository = orderRepository;
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
        this.messagingTemplate = messagingTemplate;
    }

    @Transactional
    public OrderEntity checkout(Long userId) {

        List<CartItem> cartItems = cartRepository.findByUserId(userId);

        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        double total = 0.0;

        for (CartItem item : cartItems) {
            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found: " + item.getProductId()));

            if (!"APPROVED".equals(product.getStatus())) {
                throw new RuntimeException("Only approved products can be ordered");
            }

            if (product.getQuantity() < item.getQuantity()) {
                throw new RuntimeException("Insufficient stock for product: " + product.getName());
            }

            total += product.getPrice() * item.getQuantity();
        }

        for (CartItem item : cartItems) {
            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found: " + item.getProductId()));

            product.setQuantity(product.getQuantity() - item.getQuantity());
            productRepository.save(product);
        }

        OrderEntity order = new OrderEntity();
        order.setUserId(userId);
        order.setTotalAmount(total);
        order.setStatus("PENDING_PAYMENT");

        OrderEntity savedOrder = orderRepository.save(order);

        cartRepository.deleteByUserId(userId);

        sendOrderUpdate(savedOrder.getId(), savedOrder.getStatus(), "Order created successfully");

        return savedOrder;
    }

    public OrderEntity payOrder(Long orderId) {
        OrderEntity order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));

        order.setStatus("PAID");
        OrderEntity updated = orderRepository.save(order);

        sendOrderUpdate(updated.getId(), updated.getStatus(), "Payment successful");

        return updated;
    }

    public OrderEntity updateStatus(Long orderId, String status) {
        OrderEntity order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));

        order.setStatus(status);
        OrderEntity updated = orderRepository.save(order);

        sendOrderUpdate(updated.getId(), updated.getStatus(), "Order status changed to " + status);

        return updated;
    }

    public List<OrderEntity> getUserOrders(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public OrderEntity getOrderById(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
    }

    private void sendOrderUpdate(Long orderId, String status, String message) {
        OrderStatusMessage payload = new OrderStatusMessage(orderId, status, message);
        messagingTemplate.convertAndSend("/topic/orders/" + orderId, payload);
    }
}