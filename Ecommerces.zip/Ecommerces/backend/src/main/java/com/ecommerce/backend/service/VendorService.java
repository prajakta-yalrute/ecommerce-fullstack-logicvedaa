package com.ecommerce.backend.service;

import com.ecommerce.backend.entity.User;
import com.ecommerce.backend.entity.Vendor;
import com.ecommerce.backend.repository.UserRepository;
import com.ecommerce.backend.repository.VendorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VendorService {

    private final VendorRepository vendorRepository;
    private final UserRepository userRepository;

    public VendorService(VendorRepository vendorRepository, UserRepository userRepository) {
        this.vendorRepository = vendorRepository;
        this.userRepository = userRepository;
    }

    // Apply as vendor
    public Vendor applyVendor(Long userId, String businessName) {
        Vendor vendor = new Vendor();
        vendor.setUserId(userId);
        vendor.setBusinessName(businessName);
        vendor.setKycStatus("PENDING");
        vendor.setApprovalNote("Application submitted");
        return vendorRepository.save(vendor);
    }

    // Get all pending vendors
    public List<Vendor> getPendingVendors() {
        return vendorRepository.findByKycStatus("PENDING");
    }

    // Approve vendor
    public Vendor approveVendor(Long vendorId) {
        Vendor vendor = vendorRepository.findById(vendorId).orElseThrow();

        vendor.setKycStatus("APPROVED");
        vendor.setApprovalNote("Approved by admin");

        User user = userRepository.findById(vendor.getUserId()).orElseThrow();
        user.setRole("VENDOR");
        userRepository.save(user);

        return vendorRepository.save(vendor);
    }

    // Reject vendor
    public Vendor rejectVendor(Long vendorId, String note) {
        Vendor vendor = vendorRepository.findById(vendorId).orElseThrow();
        vendor.setKycStatus("REJECTED");
        vendor.setApprovalNote(note);
        return vendorRepository.save(vendor);
    }

    public Vendor getVendorByUserId(Long userId) {
        return vendorRepository.findByUserId(userId).orElse(null);
    }
}