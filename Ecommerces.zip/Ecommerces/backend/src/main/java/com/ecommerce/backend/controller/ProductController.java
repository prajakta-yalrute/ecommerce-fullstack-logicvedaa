package com.ecommerce.backend.controller;

import com.ecommerce.backend.entity.Product;
import com.ecommerce.backend.service.ProductService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // Public: only approved products
    @GetMapping
    public List<Product> getApprovedProducts() {
        return productService.getApprovedProducts();
    }

    // Vendor: create product
    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        return productService.createProduct(product);
    }

    // Vendor: see own products
    @GetMapping("/vendor/{vendorId}")
    public List<Product> getVendorProducts(@PathVariable Long vendorId) {
        return productService.getVendorProducts(vendorId);
    }

    // Admin: see pending products
    @GetMapping("/pending")
    public List<Product> getPendingProducts() {
        return productService.getPendingProducts();
    }

    // Admin: approve product
    @PutMapping("/{productId}/approve")
    public Product approveProduct(@PathVariable Long productId) {
        return productService.approveProduct(productId);
    }

    // Admin: reject product
    @PutMapping("/{productId}/reject")
    public Product rejectProduct(@PathVariable Long productId) {
        return productService.rejectProduct(productId);
    }
}