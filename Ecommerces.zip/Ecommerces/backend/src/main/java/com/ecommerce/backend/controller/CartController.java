package com.ecommerce.backend.controller;

import com.ecommerce.backend.entity.CartItem;
import com.ecommerce.backend.service.CartService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    // Add to cart
    @PostMapping
    public CartItem addToCart(@RequestBody Map<String, String> request) {

        Long userId = Long.parseLong(request.get("userId"));
        Long productId = Long.parseLong(request.get("productId"));
        int quantity = Integer.parseInt(request.get("quantity"));

        return cartService.addToCart(userId, productId, quantity);
    }

    // Get cart
    @GetMapping("/{userId}")
    public List<CartItem> getCart(@PathVariable Long userId) {
        return cartService.getCart(userId);
    }

    // Update quantity
    @PutMapping("/{itemId}")
    public CartItem updateQuantity(@PathVariable Long itemId,
                                  @RequestBody Map<String, String> request) {

        int quantity = Integer.parseInt(request.get("quantity"));
        return cartService.updateQuantity(itemId, quantity);
    }

    // Remove item
    @DeleteMapping("/{itemId}")
    public String removeItem(@PathVariable Long itemId) {
        cartService.removeItem(itemId);
        return "Removed from cart";
    }
}