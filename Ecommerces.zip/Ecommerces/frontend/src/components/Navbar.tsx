import { Link, useNavigate } from "react-router-dom";

function Navbar() {
  const navigate = useNavigate();

  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");
  const email = localStorage.getItem("email");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("email");
    localStorage.removeItem("userId");
    localStorage.removeItem("vendorId");
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <div className="nav-left">
        <Link to="/" className="brand">E-Shop</Link>
        <Link to="/" className="nav-link">Products</Link>

        {token && <Link to="/cart" className="nav-link">Cart</Link>}
        {token && <Link to="/orders" className="nav-link">Orders</Link>}
        {role === "VENDOR" && <Link to="/vendor-products" className="nav-link">Vendor</Link>}
        {role === "ADMIN" && <Link to="/admin-products" className="nav-link">Admin</Link>}
      </div>

      <div className="nav-right">
        {token ? (
          <>
            <span className="text-muted">{email}</span>
            <span className="badge">{role}</span>
            <button className="btn btn-danger" onClick={handleLogout}>
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="nav-link">Login</Link>
            <Link to="/register" className="nav-link">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}

export default Navbar;