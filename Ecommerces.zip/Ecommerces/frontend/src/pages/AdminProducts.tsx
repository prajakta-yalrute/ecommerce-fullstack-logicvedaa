import { useEffect, useState } from "react";
import api from "../api/axios";

interface PendingProduct {
  id: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
  vendorId: number;
  status: string;
}

function AdminProducts() {
  const [products, setProducts] = useState<PendingProduct[]>([]);

  useEffect(() => {
    fetchPendingProducts();
  }, []);

  const fetchPendingProducts = async () => {
    try {
      const res = await api.get<PendingProduct[]>("/api/products/pending");
      setProducts(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  const approveProduct = async (id: number) => {
    try {
      await api.put(`/api/products/${id}/approve`);
      alert("Product approved");
      fetchPendingProducts();
    } catch (error) {
      console.error(error);
      alert("Approval failed");
    }
  };

  const rejectProduct = async (id: number) => {
    try {
      await api.put(`/api/products/${id}/reject`);
      alert("Product rejected");
      fetchPendingProducts();
    } catch (error) {
      console.error(error);
      alert("Reject failed");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Admin Product Approvals</h2>

      {products.length === 0 ? (
        <p>No pending products</p>
      ) : (
        products.map((p) => (
          <div
            key={p.id}
            style={{ border: "1px solid #ccc", marginBottom: "10px", padding: "10px" }}
          >
            <p>{p.name}</p>
            <p>{p.description}</p>
            <button onClick={() => approveProduct(p.id)}>Approve</button>
            <button onClick={() => rejectProduct(p.id)} style={{ marginLeft: "10px" }}>
              Reject
            </button>
          </div>
        ))
      )}
    </div>
  );
}

export default AdminProducts;