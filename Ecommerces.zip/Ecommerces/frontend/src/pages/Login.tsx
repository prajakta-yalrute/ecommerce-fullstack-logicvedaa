import { useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";

interface LoginForm {
  email: string;
  password: string;
}

interface LoginResponse {
  message: string;
  role: string;
  token: string;
}

interface UserResponse {
  id: number;
  name: string;
  email: string;
  role: string;
}

function Login() {
  const [form, setForm] = useState<LoginForm>({
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();

    try {
      const loginRes = await api.post<LoginResponse>("/auth/login", form);

      localStorage.setItem("token", loginRes.data.token);
      localStorage.setItem("role", loginRes.data.role);
      localStorage.setItem("email", form.email);

      const userRes = await api.get<UserResponse>(
        `/api/users/by-email?email=${encodeURIComponent(form.email)}`
      );

      localStorage.setItem("userId", userRes.data.id.toString());

      alert("Login Successful");
      navigate("/");
    } catch (error) {
      console.error(error);
      alert("Login Failed");
    }
  };

  return (
    <div className="page">
      <div className="card form-card">
        <h2 className="page-title">Login</h2>

        <form onSubmit={handleLogin}>
          <input
            className="input"
            name="email"
            placeholder="Email"
            value={form.email}
            onChange={handleChange}
          />

          <input
            className="input"
            name="password"
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
          />

          <button className="btn" type="submit">Login</button>
        </form>
      </div>
    </div>
  );
}

export default Login;