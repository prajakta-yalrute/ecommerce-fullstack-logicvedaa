import { useEffect, useState } from "react";
import api from "../api/axios";

interface CartItem {
  id: number;
  userId: number;
  productId: number;
  quantity: number;
}

function Cart() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const userId = localStorage.getItem("userId");
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (userId && token) {
      fetchCart();
    }
  }, [userId, token]);

  const fetchCart = async () => {
    try {
      const res = await api.get<CartItem[]>(`/api/cart/${userId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setCartItems(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  const checkout = async () => {
    try {
      await api.post(
        "/api/orders/checkout",
        { userId },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert("Order placed successfully");
      fetchCart();
    } catch (error: any) {
      console.error(error);
      alert(error?.response?.data?.message || "Checkout failed");
    }
  };

  if (!token || !userId) {
    return <div className="center-message">Please login first</div>;
  }

  return (
    <div className="page">
      <h2 className="page-title">Cart</h2>

      {cartItems.length === 0 ? (
        <div className="center-message">Cart is empty</div>
      ) : (
        <>
          <div className="grid">
            {cartItems.map((item) => (
              <div className="card" key={item.id}>
                <h3>Cart Item #{item.id}</h3>
                <p className="text-muted">Product ID: {item.productId}</p>
                <p className="text-muted">Quantity: {item.quantity}</p>
              </div>
            ))}
          </div>

          <div className="section-space">
            <button className="btn btn-success" onClick={checkout}>
              Checkout
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;