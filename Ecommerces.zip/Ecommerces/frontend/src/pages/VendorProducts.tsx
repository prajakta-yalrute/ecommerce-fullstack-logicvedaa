import { useEffect, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import api from "../api/axios";

interface VendorProduct {
  id: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
  vendorId: number;
  status: string;
}

interface VendorForm {
  name: string;
  description: string;
  price: string;
  quantity: string;
  vendorId: string;
}

function VendorProducts() {
  const [products, setProducts] = useState<VendorProduct[]>([]);
  const [form, setForm] = useState<VendorForm>({
    name: "",
    description: "",
    price: "",
    quantity: "",
    vendorId: "",
  });

  useEffect(() => {
    const vendorId = localStorage.getItem("vendorId");
    if (vendorId) {
      fetchVendorProducts(vendorId);
      setForm((prev) => ({ ...prev, vendorId }));
    }
  }, []);

  const fetchVendorProducts = async (vendorId: string) => {
    try {
      const res = await api.get<VendorProduct[]>(`/api/products/vendor/${vendorId}`);
      setProducts(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const addProduct = async (e: FormEvent) => {
    e.preventDefault();

    try {
      await api.post("/api/products", {
        ...form,
        price: Number(form.price),
        quantity: Number(form.quantity),
        vendorId: Number(form.vendorId),
      });

      alert("Product submitted for approval");

      setForm((prev) => ({
        ...prev,
        name: "",
        description: "",
        price: "",
        quantity: "",
      }));

      fetchVendorProducts(form.vendorId);
    } catch (error: any) {
  console.error("FULL ERROR:", error);
  console.error("RESPONSE DATA:", error?.response?.data);
  alert(error?.response?.data?.message || "Failed to add product");
}
  };

  const getStatusClass = (status: string) => {
    if (status === "APPROVED") return "status-badge status-approved";
    if (status === "PENDING") return "status-badge status-pending";
    if (status === "REJECTED") return "status-badge status-rejected";
    return "status-badge";
  };

  return (
    <div className="page">
      <h2 className="section-title">Vendor Dashboard</h2>

      <div className="vendor-layout">
        <div className="card">
          <h3 className="form-title">Add New Product</h3>

          <form onSubmit={addProduct}>
            <div className="form-grid">
              <input
                className="input form-grid-full"
                name="name"
                placeholder="Product Name"
                value={form.name}
                onChange={handleChange}
              />

              <textarea
                className="input form-grid-full"
                name="description"
                placeholder="Product Description"
                value={form.description}
                onChange={handleChange}
                rows={4}
              />

              <input
                className="input"
                name="price"
                placeholder="Price"
                value={form.price}
                onChange={handleChange}
              />

              <input
                className="input"
                name="quantity"
                placeholder="Quantity"
                value={form.quantity}
                onChange={handleChange}
              />
            </div>

            <button className="btn" type="submit">
              Submit Product
            </button>
          </form>
        </div>

        <div>
          <h3 className="form-title">My Products</h3>

          {products.length === 0 ? (
            <div className="card center-message">No vendor products found</div>
          ) : (
            <div className="grid">
              {products.map((p) => (
                <div className="card" key={p.id}>
                  <h3 className="card-title">{p.name}</h3>
                  <p className="card-subtext">{p.description}</p>
                  <div className="price">₹{p.price}</div>
                  <p className="card-subtext">Quantity: {p.quantity}</p>
                  <p className="card-subtext">Vendor ID: {p.vendorId}</p>

                  <span className={getStatusClass(p.status)}>
                    {p.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default VendorProducts;