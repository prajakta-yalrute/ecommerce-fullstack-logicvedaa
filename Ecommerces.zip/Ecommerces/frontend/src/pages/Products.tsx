import { useEffect, useState } from "react";
import api from "../api/axios";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
  vendorId: number;
  status: string;
}

function Products() {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await api.get<Product[]>("/api/products");
      setProducts(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  const addToCart = async (productId: number) => {
    const token = localStorage.getItem("token");
    const userId = localStorage.getItem("userId");

    if (!token || !userId) {
      alert("Please login first");
      return;
    }

    try {
      await api.post(
        "/api/cart",
        {
          userId,
          productId: productId.toString(),
          quantity: "1",
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert("Added to cart");
    } catch (error) {
      console.error(error);
      alert("Add to cart failed");
    }
  };

  return (
    <div className="page">
      <h2 className="page-title">Products</h2>

      {products.length === 0 ? (
        <div className="center-message">No products found</div>
      ) : (
        <div className="grid">
          {products.map((product) => (
            <div className="card" key={product.id}>
              <h3>{product.name}</h3>
              <p className="text-muted">{product.description}</p>
              <div className="price">₹{product.price}</div>
              <p className="text-muted">Stock: {product.quantity}</p>

              <div className="section-space">
                <button className="btn" onClick={() => addToCart(product.id)}>
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Products;