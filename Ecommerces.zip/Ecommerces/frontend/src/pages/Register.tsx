import { useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import api from "../api/axios";

interface RegisterForm {
  name: string;
  email: string;
  password: string;
  role: string;
}

function Register() {
  const [form, setForm] = useState<RegisterForm>({
    name: "",
    email: "",
    password: "",
    role: "CUSTOMER",
  });

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e: FormEvent) => {
    e.preventDefault();

    try {
      await api.post("/auth/register", form);
      alert("Registered Successfully");
      setForm({
        name: "",
        email: "",
        password: "",
        role: "CUSTOMER",
      });
    } catch (error) {
      console.error(error);
      alert("Registration Failed");
    }
  };

  return (
    <div className="page">
      <div className="card form-card">
        <h2 className="page-title">Create Account</h2>

        <form onSubmit={handleRegister}>
          <input
            className="input"
            name="name"
            placeholder="Name"
            value={form.name}
            onChange={handleChange}
          />

          <input
            className="input"
            name="email"
            placeholder="Email"
            value={form.email}
            onChange={handleChange}
          />

          <input
            className="input"
            name="password"
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
          />

          <select
            className="select"
            name="role"
            value={form.role}
            onChange={handleChange}
          >
            <option value="CUSTOMER">CUSTOMER</option>
            <option value="ADMIN">ADMIN</option>
          </select>

          <button className="btn" type="submit">Register</button>
        </form>
      </div>
    </div>
  );
}

export default Register;