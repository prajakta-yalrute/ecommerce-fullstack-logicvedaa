import { useEffect, useState } from "react";
import api from "../api/axios";

interface Order {
  id: number;
  userId: number;
  totalAmount: number;
  status: string;
}

function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);

  const userId = localStorage.getItem("userId");
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (userId && token) {
      fetchOrders();
    }
  }, [userId, token]);

  const fetchOrders = async () => {
    try {
      const res = await api.get<Order[]>(`/api/orders/user/${userId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setOrders(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  const payOrder = async (orderId: number) => {
    try {
      await api.put(
        `/api/orders/${orderId}/pay`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert("Payment successful");
      fetchOrders();
    } catch (error: any) {
      console.error(error);
      alert(error?.response?.data?.message || "Payment failed");
    }
  };

  if (!token || !userId) {
    return <div className="center-message">Please login first</div>;
  }

  return (
    <div className="page">
      <h2 className="page-title">Orders</h2>

      {orders.length === 0 ? (
        <div className="center-message">No orders found</div>
      ) : (
        <div className="grid">
          {orders.map((order) => (
            <div className="card" key={order.id}>
              <h3>Order #{order.id}</h3>
              <div className="price">₹{order.totalAmount}</div>
              <p className="text-muted">Status: {order.status}</p>

              {order.status === "PENDING_PAYMENT" && (
                <div className="row">
                  <button
                    className="btn btn-success"
                    onClick={() => payOrder(order.id)}
                  >
                    Pay Now
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Orders;